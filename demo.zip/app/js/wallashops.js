﻿WallaShops = {
    AnalyticsEvents: {
        ShowProduct: { Label: "הצגת מוצר"}
    }
};